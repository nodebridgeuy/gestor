SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS encuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NOT NULL UNIQUE,
  titulo VARCHAR(150) NOT NULL,
  descripcion VARCHAR(500) NULL,
  sector VARCHAR(100) NOT NULL,
  preguntas MEDIUMTEXT NOT NULL,
  INDEX idx_encuestas_sector (sector)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE respuestas
  ADD COLUMN IF NOT EXISTS encuesta_externo INT NULL AFTER uuid,
  ADD COLUMN IF NOT EXISTS respuestas_json MEDIUMTEXT NULL AFTER encuesta_externo,
  MODIFY clasificacion VARCHAR(20) NULL,
  MODIFY lugar VARCHAR(50) NULL,
  MODIFY profesional VARCHAR(50) NULL;
