SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS categorias (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documentos (
  id_documento INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NULL UNIQUE,
  titulo VARCHAR(150) NOT NULL,
  ruta_archivo VARCHAR(255) NOT NULL UNIQUE,
  fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP,
  categoria_id INT NOT NULL,
  INDEX idx_documentos_categoria (categoria_id),
  FOREIGN KEY (categoria_id) REFERENCES categorias(id_categoria) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS encuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NOT NULL UNIQUE,
  titulo VARCHAR(150) NOT NULL,
  descripcion VARCHAR(500) NULL,
  sector VARCHAR(100) NOT NULL,
  preguntas MEDIUMTEXT NOT NULL,
  INDEX idx_encuestas_sector (sector)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS respuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,
  encuesta_externo INT NULL,
  respuestas_json MEDIUMTEXT NULL,
  clasificacion VARCHAR(20) NULL,
  lugar VARCHAR(50) NULL,
  profesional VARCHAR(50) NULL,
  comentario VARCHAR(255) NULL,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  sincronizado TINYINT(1) NOT NULL DEFAULT 0,
  fecha_sincronizado DATETIME NULL,
  ip_hash CHAR(64) NULL,
  INDEX idx_respuestas_pendientes (sincronizado, id),
  INDEX idx_respuestas_ip (ip_hash, fecha)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
