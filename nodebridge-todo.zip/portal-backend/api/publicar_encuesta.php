<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}
$d = json_entrada(102400);

$idExterno = filter_var($d['id_externo'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idExterno === false || $idExterno === null) {
    error_out('id_externo inválido', 422);
}
$texto = fn($v) => is_string($v) ? trim($v) : '';
$titulo = $texto($d['titulo'] ?? null);
$descripcion = $texto($d['descripcion'] ?? null);
$sector = $texto($d['sector'] ?? null);
if ($titulo === '' || longitud_texto($titulo) > 150) {
    error_out('Título inválido (1 a 150 caracteres)', 422);
}
if (longitud_texto($descripcion) > 500) {
    error_out('La descripción no puede superar los 500 caracteres', 422);
}
if ($sector === '' || longitud_texto($sector) > 100) {
    error_out('Sector inválido (1 a 100 caracteres)', 422);
}

$crudas = $d['preguntas'] ?? null;
if (!is_array($crudas) || count($crudas) < 1 || count($crudas) > 30) {
    error_out('La encuesta debe tener entre 1 y 30 preguntas', 422);
}

$preguntas = [];
$ids = [];
foreach ($crudas as $i => $p) {
    $n = $i + 1;
    if (!is_array($p)) {
        error_out("Pregunta $n inválida", 422);
    }
    $id = filter_var($p['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false || $id === null || in_array($id, $ids, true)) {
        error_out("La pregunta $n tiene un id inválido o repetido", 422);
    }
    $ids[] = $id;
    $t = $texto($p['texto'] ?? null);
    if ($t === '' || longitud_texto($t) > 255) {
        error_out("La pregunta $n debe tener un texto de hasta 255 caracteres", 422);
    }
    $tipo = $p['tipo'] ?? '';
    if (!in_array($tipo, ['escala', 'opcion', 'texto'], true)) {
        error_out("La pregunta $n tiene un tipo no válido", 422);
    }
    $opciones = [];
    if ($tipo === 'opcion') {
        $lista = is_array($p['opciones'] ?? null) ? $p['opciones'] : [];
        foreach ($lista as $o) {
            $o = $texto($o);
            if ($o === '' || longitud_texto($o) > 100) {
                error_out("Las opciones de la pregunta $n deben tener entre 1 y 100 caracteres", 422);
            }
            $opciones[] = $o;
        }
        $opciones = array_values(array_unique($opciones));
        if (count($opciones) < 2 || count($opciones) > 15) {
            error_out("La pregunta $n debe tener entre 2 y 15 opciones", 422);
        }
    }
    $preguntas[] = ['id' => $id, 'texto' => $t, 'tipo' => $tipo, 'opciones' => $opciones, 'obligatoria' => !empty($p['obligatoria'])];
}

$stmt = preparar(
    'INSERT INTO encuestas (id_externo, titulo, descripcion, sector, preguntas) VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE titulo = VALUES(titulo), descripcion = VALUES(descripcion),
                             sector = VALUES(sector), preguntas = VALUES(preguntas)',
    [$idExterno, $titulo, $descripcion !== '' ? $descripcion : null, $sector, json_encode($preguntas, JSON_UNESCAPED_UNICODE)]
);
$creada = $stmt->rowCount() === 1;
json_out(['estado' => 'exito', 'accion' => $creada ? 'creada' : 'actualizada'], $creada ? 201 : 200);
