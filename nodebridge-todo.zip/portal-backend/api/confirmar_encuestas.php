<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}
$datos = json_decode((string) file_get_contents('php://input'), true);
$uuids = is_array($datos) && isset($datos['uuids']) && is_array($datos['uuids']) ? $datos['uuids'] : null;
if ($uuids === null || count($uuids) === 0 || count($uuids) > 500) {
    error_out('Lista de uuids inválida (1 a 500)', 422);
}
foreach ($uuids as $u) {
    if (!is_string($u) || !preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $u)) {
        error_out('uuid inválido', 422);
    }
}

$marcas = implode(',', array_fill(0, count($uuids), '?'));
$stmt = preparar(
    "UPDATE respuestas SET sincronizado = 1, fecha_sincronizado = NOW()
      WHERE sincronizado = 0 AND uuid IN ($marcas)",
    $uuids
);
json_out(['estado' => 'exito', 'confirmadas' => $stmt->rowCount()]);
