

window.PORTAL_CONFIG = {

  BACKEND_URL: '/portal-backend',

}
