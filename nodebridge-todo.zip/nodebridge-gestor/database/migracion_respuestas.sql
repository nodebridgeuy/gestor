USE `sigsm`;
SET NAMES utf8mb4;

ALTER TABLE `respuesta_encuesta` ADD COLUMN IF NOT EXISTS `id_encuesta` INT NULL;
ALTER TABLE `respuesta_encuesta` ADD INDEX IF NOT EXISTS `idx_respuesta_encuesta` (`id_encuesta`);

SET @fk := (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'respuesta_encuesta'
     AND CONSTRAINT_NAME = 'fk_respuesta_id_encuesta'
);
SET @sql := IF(@fk = 0,
  'ALTER TABLE `respuesta_encuesta` ADD CONSTRAINT `fk_respuesta_id_encuesta` FOREIGN KEY (`id_encuesta`) REFERENCES `encuesta` (`id_encuesta`) ON DELETE SET NULL',
  'DO 0');
PREPARE paso FROM @sql;
EXECUTE paso;
DEALLOCATE PREPARE paso;
