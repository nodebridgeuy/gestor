CREATE DATABASE IF NOT EXISTS `sigsm`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sigsm`;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `traslado`, `conductor`, `solicitud_clave`, `intento_login`, `respuesta_detalle`, `ambulancia`, `respuesta`, `pregunta`, `encuesta`, `sector`, `sincronizacion`,
                     `respuesta_encuesta`, `documento`, `categoria`, `funcionario`, `rol`;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `rol` (
  `id_rol` INT NOT NULL PRIMARY KEY,
  `nombre_rol` VARCHAR(40) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `rol` (`id_rol`, `nombre_rol`) VALUES
  (1, 'Administrador'),
  (2, 'Funcionario');

CREATE TABLE `funcionario` (
  `id_funcionario` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(50) NOT NULL UNIQUE,
  `contrasena` VARCHAR(255) NOT NULL,
  `id_rol` INT NOT NULL,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  `email` VARCHAR(70) NULL UNIQUE,
  `cedula` VARCHAR(8) NULL UNIQUE,
  `debe_cambiar_clave` TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT `fk_funcionario_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`)
) ENGINE=InnoDB;

CREATE TABLE `categoria` (
  `id_categoria` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO `categoria` (`nombre`) VALUES
  ('Unidad de Cuidados Paliativos'),
  ('Emergencia'),
  ('Neonatología'),
  ('Dpto. Clínico de medicina'),
  ('Cardiología'),
  ('Centro cardiovascular'),
  ('Clínica médica A'),
  ('Clínica médica B'),
  ('Clínica médica C'),
  ('Dermatología'),
  ('Endocrinología'),
  ('Gastroenterología'),
  ('Geriatría'),
  ('Hematología'),
  ('Infectología'),
  ('Medicina física, rehabilitación y medicina del deporte'),
  ('Nefrología'),
  ('Neurología'),
  ('Oncología'),
  ('Psiquiatría'),
  ('U.E. Autoinmunes sistémicas'),
  ('Unidad de tabaquismo'),
  ('Depto. Clínico de cirugía'),
  ('Anestesiología'),
  ('Cirugía plástica y quemados'),
  ('Cirugía vascular periférica'),
  ('Ginecotocológica B'),
  ('Neurocirugía'),
  ('Odontología'),
  ('Oftalmología'),
  ('Otorrinolaringología'),
  ('Quirúrgica A'),
  ('Quirúrgica B'),
  ('Quirúrgica F'),
  ('Urología'),
  ('Traumatología y ortopedia de adultos'),
  ('Radioterapia'),
  ('Medicina Nuclear'),
  ('Hemoterapia'),
  ('Imagenología');

CREATE TABLE `documento` (
  `id_documento` INT AUTO_INCREMENT PRIMARY KEY,
  `titulo_documento` VARCHAR(150) NOT NULL,
  `id_categoria` INT NOT NULL,
  `id_funcionario` INT NOT NULL,
  `ruta_archivo` VARCHAR(255) NOT NULL UNIQUE,
  `nombre_original` VARCHAR(255) NOT NULL,
  `tamano` INT NOT NULL DEFAULT 0,
  `es_guia_general` TINYINT(1) NOT NULL DEFAULT 0,
  `estado_portal` TINYINT(1) NOT NULL DEFAULT 0,
  `fecha_subida` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_documento_guia` (`es_guia_general`),
  INDEX `idx_documento_categoria` (`id_categoria`),
  INDEX `idx_documento_fecha` (`fecha_subida`),
  CONSTRAINT `fk_documento_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_documento_funcionario` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`)
) ENGINE=InnoDB;

CREATE TABLE `respuesta_encuesta` (
  `id_respuesta` INT AUTO_INCREMENT PRIMARY KEY,
  `uuid` CHAR(36) NOT NULL UNIQUE,
  `clasificacion` VARCHAR(20) NULL,
  `lugar` VARCHAR(50) NULL,
  `profesional` VARCHAR(50) NULL,
  `comentario` VARCHAR(255) NULL,
  `fecha_portal` DATETIME NOT NULL,
  `fecha_recibida` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_encuesta` INT NULL,
  INDEX `idx_respuesta_fecha` (`fecha_portal`),
  INDEX `idx_respuesta_encuesta` (`id_encuesta`)
) ENGINE=InnoDB;

CREATE TABLE `sincronizacion` (
  `clave` VARCHAR(40) NOT NULL PRIMARY KEY,
  `ultimo_intento` DATETIME NULL,
  `ultimo_exito` DATETIME NULL,
  `ultimo_error` VARCHAR(255) NULL
) ENGINE=InnoDB;

INSERT INTO `sincronizacion` (`clave`) VALUES ('encuestas');

CREATE TABLE `sector` (
  `id_sector` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_sector` VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO `sector` (`nombre_sector`) VALUES
  ('Enfermería'),
  ('Servicio web'),
  ('Admisiones'),
  ('Mantenimiento');

CREATE TABLE `encuesta` (
  `id_encuesta` INT AUTO_INCREMENT PRIMARY KEY,
  `titulo_encuesta` VARCHAR(150) NOT NULL,
  `descripcion` VARCHAR(500) NULL,
  `id_sector` INT NOT NULL,
  `id_funcionario` INT NOT NULL,
  `activa` TINYINT(1) NOT NULL DEFAULT 0,
  `estado_portal` TINYINT(1) NOT NULL DEFAULT 0,
  `fecha_creacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_encuesta_sector_titulo` (`id_sector`, `titulo_encuesta`),
  INDEX `idx_encuesta_titulo` (`titulo_encuesta`),
  CONSTRAINT `fk_encuesta_id_sector` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id_sector`),
  CONSTRAINT `fk_encuesta_id_funcionario` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`)
) ENGINE=InnoDB;

CREATE TABLE `pregunta` (
  `id_pregunta` INT AUTO_INCREMENT PRIMARY KEY,
  `id_encuesta` INT NOT NULL,
  `texto_pregunta` VARCHAR(255) NOT NULL,
  `tipo` ENUM('escala', 'opcion', 'texto') NOT NULL DEFAULT 'escala',
  `opciones` TEXT NULL,
  `obligatoria` TINYINT(1) NOT NULL DEFAULT 1,
  `orden` SMALLINT NOT NULL DEFAULT 1,
  INDEX `idx_pregunta_encuesta` (`id_encuesta`, `orden`),
  CONSTRAINT `fk_pregunta_id_encuesta` FOREIGN KEY (`id_encuesta`) REFERENCES `encuesta` (`id_encuesta`) ON DELETE CASCADE
) ENGINE=InnoDB;

ALTER TABLE `respuesta_encuesta`
  ADD CONSTRAINT `fk_respuesta_id_encuesta` FOREIGN KEY (`id_encuesta`) REFERENCES `encuesta` (`id_encuesta`) ON DELETE SET NULL;

CREATE TABLE `respuesta_detalle` (
  `id_detalle` INT AUTO_INCREMENT PRIMARY KEY,
  `id_respuesta` INT NOT NULL,
  `id_pregunta` INT NULL,
  `texto_pregunta` VARCHAR(255) NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `valor` VARCHAR(500) NOT NULL,
  INDEX `idx_detalle_respuesta` (`id_respuesta`),
  CONSTRAINT `fk_detalle_id_respuesta` FOREIGN KEY (`id_respuesta`) REFERENCES `respuesta_encuesta` (`id_respuesta`) ON DELETE CASCADE,
  CONSTRAINT `fk_detalle_id_pregunta` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `conductor` (
  `id_conductor` INT AUTO_INCREMENT PRIMARY KEY,
  `cedula` VARCHAR(8) NULL UNIQUE,
  `nombre_completo` VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `ambulancia` (
  `id_ambulancia` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(50) NOT NULL UNIQUE,
  `matricula` VARCHAR(10) NULL UNIQUE,
  `id_conductor` INT NULL,
  `estado` ENUM('disponible', 'en_camino', 'llego_destino', 'volviendo', 'fuera_servicio') NOT NULL DEFAULT 'disponible',
  `fecha_estado` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ambulancia_estado` (`estado`),
  CONSTRAINT `fk_ambulancia_conductor` FOREIGN KEY (`id_conductor`) REFERENCES `conductor` (`id_conductor`)
) ENGINE=InnoDB;

CREATE TABLE `traslado` (
  `id_traslado` INT AUTO_INCREMENT PRIMARY KEY,
  `cedula_paciente` VARCHAR(8) NOT NULL,
  `nombre_paciente` VARCHAR(100) NOT NULL,
  `tipo_contaminacion` VARCHAR(100) NOT NULL,
  `origen` VARCHAR(150) NOT NULL,
  `destino` VARCHAR(150) NOT NULL,
  `fecha_salida` DATETIME NOT NULL,
  `fecha_llegada` DATETIME NOT NULL,
  `recibe_destino` VARCHAR(100) NOT NULL,
  `estado` VARCHAR(15) NOT NULL DEFAULT 'pendiente',
  `id_solicitante` INT NOT NULL,
  `id_ambulancia` INT NULL,
  `motivo` VARCHAR(255) NULL,
  `fecha_solicitud` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_asignacion` DATETIME NULL,
  INDEX `idx_traslado_estado` (`estado`),
  INDEX `idx_traslado_solicitante` (`id_solicitante`),
  INDEX `idx_traslado_ambulancia` (`id_ambulancia`, `estado`),
  CONSTRAINT `fk_traslado_solicitante` FOREIGN KEY (`id_solicitante`) REFERENCES `funcionario` (`id_funcionario`),
  CONSTRAINT `fk_traslado_ambulancia` FOREIGN KEY (`id_ambulancia`) REFERENCES `ambulancia` (`id_ambulancia`)
) ENGINE=InnoDB;

CREATE TABLE `solicitud_clave` (
  `id_solicitud` INT AUTO_INCREMENT PRIMARY KEY,
  `id_funcionario` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `atendida` TINYINT(1) NOT NULL DEFAULT 0,
  INDEX `idx_solicitud_pendiente` (`atendida`, `id_funcionario`),
  CONSTRAINT `fk_solicitud_funcionario` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `intento_login` (
  `id_intento` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario` VARCHAR(50) NOT NULL,
  `ip` VARCHAR(45) NOT NULL,
  `fecha` DATETIME NOT NULL,
  INDEX `idx_intento_fecha` (`fecha`)
) ENGINE=InnoDB;

INSERT INTO `funcionario` (`nombre`, `contrasena`, `id_rol`, `activo`, `email`, `cedula`) VALUES
  ('admin', '$2y$10$6eo3h4S3ZkkpdWE5hCZ0Zu.42NZG7zJsDhk5vMfLsk1eimanMN8qG', 1, 1, NULL, '11111111');
