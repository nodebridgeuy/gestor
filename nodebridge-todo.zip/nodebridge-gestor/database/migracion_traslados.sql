USE `sigsm`;
SET NAMES utf8mb4;

ALTER TABLE `ambulancia` ADD COLUMN IF NOT EXISTS `matricula` VARCHAR(10) NULL AFTER `nombre`;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_ambulancia_matricula` ON `ambulancia` (`matricula`);

CREATE TABLE IF NOT EXISTS `traslado` (
  `id_traslado` INT AUTO_INCREMENT PRIMARY KEY,
  `cedula_paciente` VARCHAR(8) NOT NULL,
  `nombre_paciente` VARCHAR(100) NOT NULL,
  `tipo_contaminacion` VARCHAR(100) NOT NULL,
  `origen` VARCHAR(150) NOT NULL,
  `destino` VARCHAR(150) NOT NULL,
  `fecha_salida` DATETIME NOT NULL,
  `fecha_llegada` DATETIME NOT NULL,
  `recibe_destino` VARCHAR(100) NOT NULL,
  `estado` VARCHAR(15) NOT NULL DEFAULT 'pendiente',
  `id_solicitante` INT NOT NULL,
  `id_ambulancia` INT NULL,
  `motivo` VARCHAR(255) NULL,
  `fecha_solicitud` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_asignacion` DATETIME NULL,
  INDEX `idx_traslado_estado` (`estado`),
  INDEX `idx_traslado_solicitante` (`id_solicitante`),
  INDEX `idx_traslado_ambulancia` (`id_ambulancia`, `estado`),
  CONSTRAINT `fk_traslado_solicitante` FOREIGN KEY (`id_solicitante`) REFERENCES `funcionario` (`id_funcionario`),
  CONSTRAINT `fk_traslado_ambulancia` FOREIGN KEY (`id_ambulancia`) REFERENCES `ambulancia` (`id_ambulancia`)
) ENGINE=InnoDB;
