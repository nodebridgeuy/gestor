USE `sigsm`;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `conductor` (
  `id_conductor` INT AUTO_INCREMENT PRIMARY KEY,
  `cedula` VARCHAR(8) NULL UNIQUE,
  `nombre_completo` VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

ALTER TABLE `ambulancia` ADD COLUMN IF NOT EXISTS `id_conductor` INT NULL;

INSERT INTO `conductor` (`nombre_completo`)
  SELECT DISTINCT a.`conductor` FROM `ambulancia` a
   WHERE a.`id_conductor` IS NULL AND a.`conductor` IS NOT NULL AND a.`conductor` <> ''
     AND NOT EXISTS (SELECT 1 FROM `conductor` c WHERE c.`nombre_completo` = a.`conductor`);

UPDATE `ambulancia` a JOIN `conductor` c ON c.`nombre_completo` = a.`conductor`
   SET a.`id_conductor` = c.`id_conductor`
 WHERE a.`id_conductor` IS NULL AND a.`conductor` IS NOT NULL AND a.`conductor` <> '';

ALTER TABLE `ambulancia`
  ADD CONSTRAINT `fk_ambulancia_conductor` FOREIGN KEY (`id_conductor`) REFERENCES `conductor` (`id_conductor`);
