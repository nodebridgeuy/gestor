USE `sigsm`;
SET NAMES utf8mb4;

INSERT IGNORE INTO `conductor` (`cedula`, `nombre_completo`) VALUES
  ('10000014', 'Carlos Pérez'),
  ('20000028', 'Laura Gómez'),
  ('30000032', 'Martín Rodríguez'),
  ('40000046', 'Sofía Fernández'),
  ('50000050', 'Diego Suárez');

INSERT IGNORE INTO `ambulancia` (`nombre`, `matricula`, `id_conductor`, `estado`, `fecha_estado`) VALUES
  ('Ambulancia 1', 'SAA 1234', (SELECT `id_conductor` FROM `conductor` WHERE `cedula` = '10000014'), 'disponible',     DATE_SUB(NOW(), INTERVAL 25 MINUTE)),
  ('Ambulancia 2', 'SAB 2345', (SELECT `id_conductor` FROM `conductor` WHERE `cedula` = '20000028'), 'disponible',     DATE_SUB(NOW(), INTERVAL 40 MINUTE)),
  ('Ambulancia 3', 'SAC 3456', (SELECT `id_conductor` FROM `conductor` WHERE `cedula` = '30000032'), 'disponible',     DATE_SUB(NOW(), INTERVAL 1 HOUR)),
  ('Ambulancia 4', 'SAD 4567', (SELECT `id_conductor` FROM `conductor` WHERE `cedula` = '40000046'), 'disponible',     DATE_SUB(NOW(), INTERVAL 90 MINUTE)),
  ('Ambulancia 5', 'SAE 5678', (SELECT `id_conductor` FROM `conductor` WHERE `cedula` = '50000050'), 'fuera_servicio', DATE_SUB(NOW(), INTERVAL 2 HOUR));
