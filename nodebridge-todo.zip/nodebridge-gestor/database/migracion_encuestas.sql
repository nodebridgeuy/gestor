USE `sigsm`;
SET NAMES utf8mb4;

SET @encuesta_vieja := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'encuesta' AND COLUMN_NAME = 'fecha_publi_encuesta'
);
SET @pregunta_vieja := (
  SELECT COUNT(*) FROM information_schema.TABLES t
   WHERE t.TABLE_SCHEMA = DATABASE() AND t.TABLE_NAME = 'pregunta'
     AND NOT EXISTS (
       SELECT 1 FROM information_schema.COLUMNS c
        WHERE c.TABLE_SCHEMA = t.TABLE_SCHEMA AND c.TABLE_NAME = 'pregunta' AND c.COLUMN_NAME = 'texto_pregunta'
     )
);

SET @sql := IF(@encuesta_vieja > 0, 'RENAME TABLE `encuesta` TO `encuesta_antigua`', 'DO 0');
PREPARE paso FROM @sql;
EXECUTE paso;
DEALLOCATE PREPARE paso;

SET @sql := IF(@pregunta_vieja > 0, 'RENAME TABLE `pregunta` TO `pregunta_antigua`', 'DO 0');
PREPARE paso FROM @sql;
EXECUTE paso;
DEALLOCATE PREPARE paso;

CREATE TABLE IF NOT EXISTS `sector` (
  `id_sector` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_sector` VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO `sector` (`nombre_sector`)
SELECT 'Enfermería' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM `sector` WHERE `nombre_sector` = 'Enfermería');

INSERT INTO `sector` (`nombre_sector`)
SELECT 'Servicio web' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM `sector` WHERE `nombre_sector` = 'Servicio web');

INSERT INTO `sector` (`nombre_sector`)
SELECT 'Admisiones' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM `sector` WHERE `nombre_sector` = 'Admisiones');

INSERT INTO `sector` (`nombre_sector`)
SELECT 'Mantenimiento' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM `sector` WHERE `nombre_sector` = 'Mantenimiento');

CREATE TABLE IF NOT EXISTS `encuesta` (
  `id_encuesta` INT AUTO_INCREMENT PRIMARY KEY,
  `titulo_encuesta` VARCHAR(150) NOT NULL,
  `descripcion` VARCHAR(500) NULL,
  `id_sector` INT NOT NULL,
  `id_funcionario` INT NOT NULL,
  `activa` TINYINT(1) NOT NULL DEFAULT 0,
  `fecha_creacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_encuesta_sector_titulo` (`id_sector`, `titulo_encuesta`),
  INDEX `idx_encuesta_titulo` (`titulo_encuesta`),
  CONSTRAINT `fk_encuesta_id_sector` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id_sector`),
  CONSTRAINT `fk_encuesta_id_funcionario` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pregunta` (
  `id_pregunta` INT AUTO_INCREMENT PRIMARY KEY,
  `id_encuesta` INT NOT NULL,
  `texto_pregunta` VARCHAR(255) NOT NULL,
  `tipo` ENUM('escala', 'opcion', 'texto') NOT NULL DEFAULT 'escala',
  `opciones` TEXT NULL,
  `obligatoria` TINYINT(1) NOT NULL DEFAULT 1,
  `orden` SMALLINT NOT NULL DEFAULT 1,
  INDEX `idx_pregunta_encuesta` (`id_encuesta`, `orden`),
  CONSTRAINT `fk_pregunta_id_encuesta` FOREIGN KEY (`id_encuesta`) REFERENCES `encuesta` (`id_encuesta`) ON DELETE CASCADE
) ENGINE=InnoDB;
