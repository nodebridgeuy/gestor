<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/traslados.php';

requerir_admin();
$pdo = db();

$activos = ESTADOS_TRASLADO_ACTIVOS;
$marcas = implode(',', array_fill(0, count($activos), '?'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigir_post_con_csrf();
    $accion = (string) ($_POST['accion'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);

    $ocupada = function (int $idAmb) use ($pdo, $marcas, $activos): bool {
        $q = $pdo->prepare("SELECT 1 FROM traslado WHERE id_ambulancia = ? AND estado IN ($marcas) LIMIT 1");
        $q->execute(array_merge([$idAmb], $activos));
        return (bool) $q->fetchColumn();
    };

    if ($accion === 'guardar') {
        $nombre = trim((string) ($_POST['nombre'] ?? ''));
        $matricula = normalizar_matricula((string) ($_POST['matricula'] ?? ''));
        $idConductor = (int) ($_POST['conductor'] ?? 0);
        $error = '';
        if ($nombre === '' || mb_strlen($nombre) > 50) {
            $error = 'Ingrese un nombre de hasta 50 caracteres (por ejemplo «Ambulancia 1»).';
        } elseif ($matricula === null) {
            $error = 'La matrícula no es válida (de 4 a 10 letras o números).';
        } else {
            $q = $pdo->prepare('SELECT 1 FROM conductor WHERE id_conductor = ?');
            $q->execute([$idConductor]);
            if (!$q->fetchColumn()) {
                $error = 'Elija el conductor: toda ambulancia tiene que tener uno.';
            } else {
                $q = $pdo->prepare('SELECT nombre FROM ambulancia WHERE id_conductor = ? AND id_ambulancia <> ?');
                $q->execute([$idConductor, $id]);
                if ($otra = $q->fetchColumn()) {
                    $error = 'Ese conductor ya está asignado a «' . $otra . '».';
                }
            }
        }
        if ($error === '') {
            try {
                if ($id > 0) {
                    $pdo->prepare('UPDATE ambulancia SET nombre = ?, matricula = ?, id_conductor = ? WHERE id_ambulancia = ?')
                        ->execute([$nombre, $matricula, $idConductor, $id]);
                    avisar('Ambulancia actualizada.');
                } else {
                    $pdo->prepare("INSERT INTO ambulancia (nombre, matricula, id_conductor, estado, fecha_estado) VALUES (?, ?, ?, 'disponible', ?)")
                        ->execute([$nombre, $matricula, $idConductor, date('Y-m-d H:i:s')]);
                    avisar('Ambulancia registrada.');
                }
                redirigir('traslados/ambulancias.php');
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $error = 'Ya existe una ambulancia con ese nombre o esa matrícula.';
                } else {
                    error_log('[sigsm] ' . $e->getMessage());
                    $error = 'No se pudo guardar. Intente de nuevo.';
                }
            }
        }
        avisar($error, 'danger');
        redirigir('traslados/ambulancias.php' . ($id > 0 ? '?id=' . $id : ''));
    }

    if ($accion === 'servicio') {
        $fuera = ($_POST['fuera'] ?? '') === '1';
        if ($ocupada($id)) {
            avisar('La ambulancia está en un traslado en curso. Espere a que termine.', 'warning');
        } else {
            $nuevo = $fuera ? 'fuera_servicio' : 'disponible';
            $pdo->prepare("UPDATE ambulancia SET estado = ?, fecha_estado = ? WHERE id_ambulancia = ? AND estado IN ('disponible', 'fuera_servicio')")
                ->execute([$nuevo, date('Y-m-d H:i:s'), $id]);
            avisar($fuera ? 'Ambulancia fuera de servicio.' : 'Ambulancia disponible.');
        }
        redirigir('traslados/ambulancias.php');
    }

    if ($accion === 'eliminar') {
        try {
            $r = $pdo->prepare('DELETE FROM ambulancia WHERE id_ambulancia = ?');
            $r->execute([$id]);
            avisar($r->rowCount() > 0 ? 'Ambulancia eliminada.' : 'La ambulancia no existe.', $r->rowCount() > 0 ? 'success' : 'warning');
        } catch (PDOException $e) {
            avisar('No se puede eliminar: tiene traslados registrados. Póngala fuera de servicio.', 'warning');
        }
        redirigir('traslados/ambulancias.php');
    }
    redirigir('traslados/ambulancias.php');
}

$ambulancias = $pdo->query(
    'SELECT a.id_ambulancia, a.nombre, a.matricula, a.id_conductor, c.nombre_completo AS conductor, a.estado, a.fecha_estado
       FROM ambulancia a LEFT JOIN conductor c ON c.id_conductor = a.id_conductor ORDER BY a.nombre'
)->fetchAll();
$conductores = $pdo->query('SELECT id_conductor, nombre_completo, cedula FROM conductor ORDER BY nombre_completo')->fetchAll();
$ocupados = array_filter(array_column($ambulancias, 'id_conductor'));

$editar = null;
$idEditar = (int) ($_GET['id'] ?? 0);
foreach ($ambulancias as $a) {
    if ((int) $a['id_ambulancia'] === $idEditar) {
        $editar = $a;
    }
}

encabezado('Ambulancias', 'traslados');
?>
<p class="d-flex justify-content-between">
    <a href="<?= h(url('traslados/index.php')) ?>">&larr; Volver a traslados</a>
    <a class="btn btn-sm btn-outline-secondary" href="<?= h(url('traslados/conductores.php')) ?>">Conductores</a>
</p>

<div class="row g-4">
    <div class="col-12 col-xl-5">
        <div class="card">
            <div class="card-header fw-semibold"><?= $editar ? 'Editar ambulancia' : 'Registrar ambulancia' ?></div>
            <div class="card-body">
                <form method="POST" autocomplete="off">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="guardar">
                    <input type="hidden" name="id" value="<?= (int) ($editar['id_ambulancia'] ?? 0) ?>">
                    <div class="mb-3">
                        <label class="form-label" for="nombre">Nombre</label>
                        <input class="form-control" id="nombre" name="nombre" maxlength="50" required placeholder="Ambulancia 6" value="<?= h($editar['nombre'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="matricula">Matrícula</label>
                        <input class="form-control" id="matricula" name="matricula" maxlength="10" required placeholder="SAA 1234" value="<?= h($editar['matricula'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="conductor">Conductor</label>
                        <select class="form-select" id="conductor" name="conductor" required>
                            <option value="">-- Elija un conductor --</option>
                            <?php foreach ($conductores as $c):
                                $idC = (int) $c['id_conductor'];
                                $propio = $editar && (int) $editar['id_conductor'] === $idC;
                                $libre = $propio || !in_array($idC, array_map('intval', $ocupados), true); ?>
                                <?php if ($libre): ?>
                                    <option value="<?= $idC ?>"<?= $propio ? ' selected' : '' ?>><?= h($c['nombre_completo']) ?><?= $c['cedula'] ? ' · ' . h(formatear_cedula($c['cedula'])) : '' ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">
                            Toda ambulancia tiene un conductor, aunque esté disponible. Si no está en la lista,
                            <a href="<?= h(url('traslados/conductores.php')) ?>">regístrelo primero</a>.
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit"><?= $editar ? 'Guardar cambios' : 'Registrar' ?></button>
                    <?php if ($editar): ?><a class="btn btn-outline-secondary" href="<?= h(url('traslados/ambulancias.php')) ?>">Cancelar</a><?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-7">
        <div class="card">
            <?php if (!$ambulancias): ?>
                <div class="card-body text-secondary">Todavía no hay ambulancias registradas.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle mb-0 tabla-acciones">
                        <thead><tr><th>Ambulancia</th><th>Conductor</th><th>Estado</th><th class="text-end">Acciones</th></tr></thead>
                        <tbody>
                        <?php foreach ($ambulancias as $a):
                            $idA = (int) $a['id_ambulancia'];
                            [$textoEstado, $colorEstado] = ESTADOS_AMBULANCIA[$a['estado']] ?? [$a['estado'], 'secondary'];
                            $puedeServicio = in_array($a['estado'], ['disponible', 'fuera_servicio'], true); ?>
                            <tr>
                                <td class="fw-semibold"><?= h($a['nombre']) ?>
                                    <div class="small text-secondary fw-normal"><?= $a['matricula'] ? h($a['matricula']) : '<span class="badge text-bg-warning">Falta matrícula</span>' ?></div></td>
                                <td><?= $a['conductor'] ? h($a['conductor']) : '<span class="badge text-bg-warning">Falta conductor</span>' ?></td>
                                <td><span class="badge text-bg-<?= h($colorEstado) ?>"><?= h($textoEstado) ?></span></td>
                                <td class="text-end text-nowrap">
                                    <a class="btn btn-sm btn-outline-warning" href="<?= h(url('traslados/ambulancias.php?id=' . $idA)) ?>">Editar</a>
                                    <?php if ($puedeServicio): ?>
                                        <form method="POST">
                                            <?= csrf_campo() ?>
                                            <input type="hidden" name="accion" value="servicio">
                                            <input type="hidden" name="id" value="<?= $idA ?>">
                                            <input type="hidden" name="fuera" value="<?= $a['estado'] === 'disponible' ? 1 : 0 ?>">
                                            <button class="btn btn-sm btn-outline-secondary" type="submit"><?= $a['estado'] === 'disponible' ? 'Fuera de servicio' : 'Poner disponible' ?></button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" onsubmit="return confirm('¿Eliminar esta ambulancia? Solo se puede si nunca tuvo traslados.');">
                                        <?= csrf_campo() ?>
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="id" value="<?= $idA ?>">
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php pie(); ?>
