<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/traslados.php';

$admin = requerir_admin();
$pdo = db();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$st = $pdo->prepare("SELECT * FROM traslado WHERE id_traslado = ? AND estado = 'pendiente'");
$st->execute([$id]);
$t = $st->fetch();
if (!$t) {
    avisar('La solicitud no existe o ya fue atendida.', 'warning');
    redirigir('traslados/index.php');
}

$ambulancias = ambulancias_asignables();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigir_post_con_csrf();
    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion === 'rechazar') {
        $motivo = mb_substr(trim((string) ($_POST['motivo'] ?? '')), 0, 255);
        $r = $pdo->prepare("UPDATE traslado SET estado = 'rechazado', motivo = ? WHERE id_traslado = ? AND estado = 'pendiente'");
        $r->execute([$motivo !== '' ? $motivo : null, $id]);
        avisar($r->rowCount() > 0 ? 'Solicitud rechazada.' : 'La solicitud ya había sido atendida.', $r->rowCount() > 0 ? 'success' : 'warning');
        redirigir('traslados/index.php');
    }

    $idAmb = (int) ($_POST['ambulancia'] ?? 0);
    $validas = array_map('intval', array_column($ambulancias, 'id_ambulancia'));
    if (!in_array($idAmb, $validas, true)) {
        $error = 'Elija una de las ambulancias disponibles.';
    } else {

        $r = $pdo->prepare("UPDATE traslado SET id_ambulancia = ?, estado = 'asignado', fecha_asignacion = ? WHERE id_traslado = ? AND estado = 'pendiente'");
        $r->execute([$idAmb, date('Y-m-d H:i:s'), $id]);
        avisar($r->rowCount() > 0 ? 'Ambulancia asignada.' : 'La solicitud ya había sido atendida.', $r->rowCount() > 0 ? 'success' : 'warning');
        redirigir('traslados/index.php');
    }
}

encabezado('Asignar ambulancia', 'traslados');
?>
<div class="card mb-4" style="max-width: 760px;">
    <div class="card-header fw-semibold">Solicitud #<?= (int) $t['id_traslado'] ?></div>
    <div class="card-body">
        <dl class="row mb-0">
            <dt class="col-sm-4">Paciente</dt><dd class="col-sm-8"><?= h($t['nombre_paciente']) ?> (<?= h(formatear_cedula($t['cedula_paciente'])) ?>)</dd>
            <dt class="col-sm-4">Contaminación</dt><dd class="col-sm-8"><?= h($t['tipo_contaminacion']) ?></dd>
            <dt class="col-sm-4">Recorrido</dt><dd class="col-sm-8"><?= h($t['origen']) ?> → <?= h($t['destino']) ?></dd>
            <dt class="col-sm-4">Salida / llegada</dt><dd class="col-sm-8"><?= h(formatear_fecha($t['fecha_salida'])) ?> / <?= h(formatear_fecha($t['fecha_llegada'])) ?></dd>
            <dt class="col-sm-4">Recibe en el destino</dt><dd class="col-sm-8"><?= h($t['recibe_destino']) ?></dd>
        </dl>
    </div>
</div>

<div class="card mb-4" style="max-width: 760px;">
    <div class="card-body">
        <?php if ($error !== ''): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
        <?php if (!$ambulancias): ?>
            <div class="alert alert-warning mb-0">
                No hay ambulancias disponibles ahora (todas están en un traslado o fuera de servicio).
                Puede <a href="<?= h(url('traslados/ambulancias.php')) ?>">revisar las ambulancias</a> o rechazar la solicitud.
            </div>
        <?php else: ?>
            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="id" value="<?= (int) $t['id_traslado'] ?>">
                <label class="form-label" for="ambulancia">Ambulancia</label>
                <select class="form-select mb-3" id="ambulancia" name="ambulancia" required>
                    <option value="">-- Elija una ambulancia disponible --</option>
                    <?php foreach ($ambulancias as $a): ?>
                        <option value="<?= (int) $a['id_ambulancia'] ?>">
                            <?= h($a['nombre']) ?> · <?= h((string) $a['matricula']) ?> · Conductor: <?= h((string) $a['conductor']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button class="btn btn-success" type="submit">Asignar</button>
                <a class="btn btn-outline-secondary" href="<?= h(url('traslados/index.php')) ?>">Volver</a>
            </form>
        <?php endif; ?>
    </div>
</div>

<div class="card" style="max-width: 760px;">
    <div class="card-body">
        <form method="POST" onsubmit="return confirm('¿Rechazar esta solicitud?');">
            <?= csrf_campo() ?>
            <input type="hidden" name="id" value="<?= (int) $t['id_traslado'] ?>">
            <input type="hidden" name="accion" value="rechazar">
            <label class="form-label" for="motivo">Rechazar la solicitud (motivo opcional, lo ve quien la pidió)</label>
            <div class="input-group">
                <input class="form-control" id="motivo" name="motivo" maxlength="255" placeholder="Ej.: no hay ambulancias en ese horario">
                <button class="btn btn-outline-danger" type="submit">Rechazar</button>
            </div>
        </form>
    </div>
</div>
<?php pie(); ?>
