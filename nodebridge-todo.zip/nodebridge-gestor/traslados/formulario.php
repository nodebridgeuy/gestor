<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/traslados.php';

$u = requerir_login();

$d = ['cedula' => '', 'nombre' => '', 'contaminacion' => '', 'origen' => '', 'destino' => '', 'salida' => '', 'llegada' => '', 'recibe' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigir_post_con_csrf();
    foreach ($d as $campo => $_) {
        $d[$campo] = trim((string) ($_POST[$campo] ?? ''));
    }
    $cedula = normalizar_cedula($d['cedula']);
    $salida = fecha_desde_formulario($d['salida']);
    $llegada = fecha_desde_formulario($d['llegada']);

    $largos = ['nombre' => 100, 'contaminacion' => 100, 'origen' => 150, 'destino' => 150, 'recibe' => 100];
    $etiquetas = ['nombre' => 'el nombre completo del paciente', 'contaminacion' => 'el tipo de contaminación (si no hay, escriba «Ninguna»)',
        'origen' => 'el origen', 'destino' => 'el destino', 'recibe' => 'quién recibe al paciente en el destino'];

    foreach ($largos as $campo => $max) {
        if ($d[$campo] === '' || mb_strlen($d[$campo]) > $max) {
            $error = 'Ingrese ' . $etiquetas[$campo] . ' (hasta ' . $max . ' caracteres).';
            break;
        }
    }
    if ($error === '' && $cedula === null) {
        $error = 'La cédula del paciente no es válida: tiene que tener 7 u 8 dígitos, por ejemplo 1.234.567-2.';
    } elseif ($error === '' && ($salida === null || $llegada === null)) {
        $error = 'Indique el horario de salida y el de llegada.';
    } elseif ($error === '' && $llegada <= $salida) {
        $error = 'El horario de llegada tiene que ser posterior al de salida.';
    }

    if ($error === '') {
        db()->prepare(
            'INSERT INTO traslado (cedula_paciente, nombre_paciente, tipo_contaminacion, origen, destino, fecha_salida, fecha_llegada,
                                   recibe_destino, estado, id_solicitante, fecha_solicitud)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$cedula, $d['nombre'], $d['contaminacion'], $d['origen'], $d['destino'], $salida, $llegada,
            $d['recibe'], 'pendiente', $u['id_funcionario'], date('Y-m-d H:i:s')]);
        avisar('Solicitud enviada. Un administrador va a asignar la ambulancia.');
        redirigir('traslados/index.php');
    }
}

encabezado('Solicitar traslado', 'traslados');
?>
<div class="card" style="max-width: 760px;">
    <div class="card-body">
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>
        <form method="POST" autocomplete="off">
            <?= csrf_campo() ?>
            <div class="row g-3">
                <div class="col-12 col-md-4">
                    <label class="form-label" for="cedula">Cédula del paciente</label>
                    <input class="form-control" id="cedula" name="cedula" required maxlength="15" inputmode="numeric"
                           placeholder="1.234.567-2" value="<?= h($d['cedula']) ?>">
                </div>
                <div class="col-12 col-md-8">
                    <label class="form-label" for="nombre">Nombre completo</label>
                    <input class="form-control" id="nombre" name="nombre" required maxlength="100" value="<?= h($d['nombre']) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label" for="contaminacion">Tipo de contaminación</label>
                    <input class="form-control" id="contaminacion" name="contaminacion" required maxlength="100"
                           placeholder="Ej.: Ninguna, contacto, gotas, aérea..." value="<?= h($d['contaminacion']) ?>">
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label" for="origen">Origen</label>
                    <input class="form-control" id="origen" name="origen" required maxlength="150"
                           placeholder="Ej.: Emergencia, piso 3 sala 2..." value="<?= h($d['origen']) ?>">
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label" for="destino">Destino</label>
                    <input class="form-control" id="destino" name="destino" required maxlength="150" value="<?= h($d['destino']) ?>">
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label" for="salida">Horario de salida</label>
                    <input class="form-control" id="salida" name="salida" type="datetime-local" required value="<?= h($d['salida']) ?>">
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label" for="llegada">Horario de llegada</label>
                    <input class="form-control" id="llegada" name="llegada" type="datetime-local" required value="<?= h($d['llegada']) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label" for="recibe">Quién recibe en el destino</label>
                    <input class="form-control" id="recibe" name="recibe" required maxlength="100" value="<?= h($d['recibe']) ?>">
                </div>
            </div>
            <div class="d-flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">Enviar solicitud</button>
                <a class="btn btn-outline-secondary" href="<?= h(url('traslados/index.php')) ?>">Cancelar</a>
            </div>
        </form>
    </div>
</div>
<?php pie(); ?>
