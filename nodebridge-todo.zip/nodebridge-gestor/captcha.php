<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/seguridad.php';

$codigo = captcha_nuevo_codigo();
if (captcha_usa_gd()) {
    captcha_imagen($codigo);
} else {
    captcha_svg($codigo);
}
