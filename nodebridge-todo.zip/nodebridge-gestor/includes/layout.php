<?php
declare(strict_types=1);

function bootstrap_css(): string
{
    if (is_file(__DIR__ . '/../assets/vendor/bootstrap/bootstrap.min.css')) {
        return url('assets/vendor/bootstrap/bootstrap.min.css');
    }
    return 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css';
}

function bootstrap_js(): string
{
    if (is_file(__DIR__ . '/../assets/vendor/bootstrap/bootstrap.bundle.min.js')) {
        return url('assets/vendor/bootstrap/bootstrap.bundle.min.js');
    }
    return 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js';
}

function opciones_menu(): array
{
    return [
        'panel'        => ['Inicio',        'panel.php',                false],
        'documentos'   => ['Documentos',    'documentos/index.php',     false],
        'guias'        => ['Guías generales', 'documentos/index.php?tipo=guias', false],
        'encuestas'    => ['Encuestas',     'encuestas/index.php',      true],
        'respuestas'   => ['Respuestas',    'encuestas/respuestas.php', true],
        'traslados'    => ['Traslados',     'traslados/index.php',      false],
        'funcionarios' => ['Funcionarios',  'funcionarios/index.php',   true],
    ];
}

function encabezado(string $titulo, string $activo): void
{
    $u = usuario_actual();

    $solicitudesClave = 0;
    $trasladosPendientes = 0;
    if ($u && es_admin()) {
        require_once __DIR__ . '/traslados.php';
        $trasladosPendientes = traslados_pendientes();
        try {
            $solicitudesClave = (int) db()->query('SELECT COUNT(*) FROM solicitud_clave WHERE atendida = 0')->fetchColumn();
        } catch (PDOException $e) {

        }
    }
    ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($titulo) ?> · S.I.G.S.M.</title>
    <link href="<?= h(bootstrap_css()) ?>" rel="stylesheet">
    <link href="<?= h(url('assets/css/estilos.css')) ?>" rel="stylesheet">
</head>
<body>
<header class="navbar navbar-dark encabezado-app px-3 py-2">
    <div class="d-flex align-items-center gap-2">
        <?php if ($u): ?>
            <button class="navbar-toggler d-md-none" type="button" data-bs-toggle="collapse"
                    data-bs-target="#menu-lateral" aria-controls="menu-lateral" aria-label="Abrir menú">
                <span class="navbar-toggler-icon"></span>
            </button>
        <?php endif; ?>
        <a class="navbar-brand mb-0 h1 fs-5" href="<?= h(url('panel.php')) ?>">Hospital de Clínicas</a>
        <span class="small d-none d-sm-inline texto-suave">S.I.G.S.M.</span>
    </div>
    <?php if ($u): ?>
        <div class="text-white small text-end">
            <?= h(nombre_visible($u['nombre'])) ?>
            <span class="badge text-bg-light ms-1"><?= h($u['nombre_rol']) ?></span>
        </div>
    <?php endif; ?>
</header>

<div class="container-fluid">
    <div class="row">
        <?php if ($u): ?>
        <nav id="menu-lateral" class="col-md-3 col-lg-2 bg-dark collapse d-md-block p-3 menu-lateral">
            <div class="list-group list-group-flush">
                <?php foreach (opciones_menu() as $clave => [$texto, $ruta, $soloAdmin]): ?>
                    <?php if ($soloAdmin && !es_admin()) { continue; } ?>
                    <a href="<?= h(url($ruta)) ?>"
                       class="list-group-item list-group-item-action bg-dark text-white border-secondary<?= $clave === $activo ? ' active' : '' ?>">
                        <?= h($texto) ?>
                        <?php if ($clave === 'traslados' && $trasladosPendientes > 0): ?>
                            <span class="badge text-bg-warning ms-1" title="Solicitudes de traslado pendientes"><?= $trasladosPendientes ?></span>
                        <?php endif; ?>
                        <?php if ($clave === 'funcionarios' && $solicitudesClave > 0): ?>
                            <span class="badge text-bg-warning ms-1" title="Solicitudes de contraseña pendientes"><?= $solicitudesClave ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
                <a href="<?= h(url('cambiar_clave.php')) ?>"
                   class="list-group-item list-group-item-action bg-dark text-white border-secondary mt-3">Cambiar mi contraseña</a>
                <a href="<?= h(url('logout.php')) ?>"
                   class="list-group-item list-group-item-action bg-dark text-danger border-secondary">Cerrar sesión</a>
            </div>
        </nav>
        <?php endif; ?>

        <main class="<?= $u ? 'col-md-9 col-lg-10' : 'col-12' ?> p-4">
            <?php foreach (avisos_pendientes() as [$tipo, $mensaje]): ?>
                <div class="alert alert-<?= h($tipo) ?> alert-dismissible fade show" role="alert">
                    <?= h($mensaje) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                </div>
            <?php endforeach; ?>
            <h1 class="h4 mb-4"><?= h($titulo) ?></h1>
<?php
}

function pie(): void
{
    ?>
        </main>
    </div>
</div>

<footer class="text-center small py-3 pie-app">
    © 2026 Hospital de Clínicas · Sistema de Gestión de Servicios Médicos · NodeBridge
</footer>

<script src="<?= h(bootstrap_js()) ?>"></script>
</body>
</html>
<?php
}
