# Portal informativo – instalación local con XAMPP

Dos carpetas, igual que los dos repos actuales:

- `portal-informativo/` → frontend (HTML, CSS y JS nativo). Es lo que irá a Vercel.
- `portal-backend/` → backend PHP. Es lo que irá a Render.

## Instalar

1. Copiar **ambas carpetas** a `C:\xampp\htdocs\`.
2. En el panel de XAMPP, iniciar **Apache** y **MySQL**.
3. phpMyAdmin → **Importar**:
   - **Instalación nueva:** `portal-backend/database/instalar_xampp.sql` (crea la base `portal_informativo`; se puede importar más de una vez).
   - **Ya tenías la base cargada:** elegir `portal_informativo` y importar `portal-backend/database/migracion_encuestas.sql` (agrega las encuestas sin borrar nada).
4. Abrir **http://localhost/portal-informativo/**

Funcionan solos: el listado, la búsqueda y la descarga de documentos. Las **encuestas** aparecen cuando el gestor las publica (ver abajo).

## Conexión con el gestor

El gestor publica acá las encuestas activas y las guías generales, y trae las respuestas de los pacientes. Siempre llama el gestor; el portal nunca llama a la intranet.

1. Copiar `portal-backend/.env.example` como `portal-backend/.env` y completar `API_KEY=` con una clave larga y secreta (el archivo debe llamarse `.env`, no `.env.txt`).
2. Poner **esa misma clave** en el `.env` del gestor (`PORTAL_API_KEY`).

| Endpoint | Quién lo usa | Qué hace |
|---|---|---|
| `obtener_encuestas.php` (GET) | página `surveys.html` | Encuestas activas por sector, con sus preguntas |
| `guardar_encuesta.php` (POST JSON) | página `surveys.html` | Guarda la respuesta de un paciente (valida, limita envíos por IP, trae campo anti-spam) |
| `api/publicar_encuesta.php` (POST JSON) | gestor | Crea o actualiza una encuesta (`id_externo` = id del gestor) |
| `api/eliminar_encuesta.php` (POST) | gestor | Retira una encuesta |
| `api/encuestas_pendientes.php` (GET) | gestor | Respuestas que el gestor todavía no confirmó |
| `api/confirmar_encuestas.php` (POST JSON) | gestor | `{"uuids": [...]}` marca como recibidas |
| `api/publicar_documento.php`, `api/eliminar_documento.php` | gestor | Guías generales (PDF) |
| `api/ping.php` | gestor / pruebas | Verifica clave y conexión |

Todo lo de `api/` exige el encabezado `X-API-Key`; si el portal no tiene `API_KEY`, queda desactivado.

## Cómo es el formulario del paciente

`surveys.html` pide el **sector**, después la **encuesta** (si el sector tiene más de una) y dibuja las preguntas que armó el administrador: **escala de 1 a 5**, **opción única** o **texto libre**, obligatorias u opcionales. Las respuestas son anónimas.

## Dónde cambia algo al pasar a internet

- **Frontend:** solo `portal-informativo/js/config.js` (`BACKEND_URL`).
- **Backend:** las claves de `.env.example` se cargan como variables de entorno en Render (no se sube el `.env`). Para Layerbase: `DB_SSL=1`, y `TRUST_PROXY=1` detrás de un proxy.
- **Archivos subidos:** `UPLOADS_DIR` apunta a la ruta del disco persistente de Render.
- **Base ya existente en la nube:** importar `migracion_encuestas.sql` sobre ella.

## Qué cambió respecto a la versión anterior

- Encuestas dinámicas por sector (reemplazan el formulario fijo de calificación + lugar + profesional).
- Los PDF se sirven con `descargar_documento.php?id=N`; ya no se expone la ruta de carpeta.
- Las respuestas se validan en el servidor, con límite de envíos por IP (5 cada 10 min) y campo anti-spam.
- La barra de búsqueda de las páginas de categoría funciona (ignora mayúsculas y tildes).
- Los errores ya no muestran datos de la conexión a la base.
