<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
manejar_errores();
cors('GET, OPTIONS');

// Encuestas disponibles para los pacientes, agrupadas por sector (solo las que el gestor dejó Activas).
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    error_out('Método no permitido', 405);
}

$filas = preparar('SELECT id_externo, titulo, descripcion, sector, preguntas FROM encuestas ORDER BY sector, titulo')
    ->get_result()->fetch_all(MYSQLI_ASSOC);

$sectores = [];
foreach ($filas as $f) {
    $preguntas = json_decode($f['preguntas'], true);
    if (!is_array($preguntas)) {
        continue;
    }
    $sectores[$f['sector']][] = [
        'id' => (int) $f['id_externo'],
        'titulo' => $f['titulo'],
        'descripcion' => $f['descripcion'] ?? '',
        'preguntas' => $preguntas,
    ];
}

$salida = [];
foreach ($sectores as $nombre => $encuestas) {
    $salida[] = ['nombre' => $nombre, 'encuestas' => $encuestas];
}

header('Cache-Control: no-cache');
json_out(['estado' => 'exito', 'sectores' => $salida]);
