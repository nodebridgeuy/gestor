<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
manejar_errores();

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($id === false || $id === null) {
    error_out('Documento inválido', 400);
}

$fila = preparar('SELECT titulo, ruta_archivo FROM documentos WHERE id_documento = ?', 'i', [$id])
    ->get_result()->fetch_assoc();
$ruta = $fila ? ruta_segura($fila['ruta_archivo']) : null;
if ($ruta === null) {
    error_out('Documento no encontrado', 404);
}

$nombre = strtr($fila['titulo'], [
    'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
    'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ñ' => 'N',
]);
$nombre = trim((string) preg_replace('/[^A-Za-z0-9._-]+/', '-', $nombre), '-');
if ($nombre === '') {
    $nombre = 'documento-' . $id;
}
$modo = isset($_GET['descargar']) ? 'attachment' : 'inline';

header('Content-Type: application/pdf');
header('Content-Length: ' . filesize($ruta));
header('Content-Disposition: ' . $modo . '; filename="' . $nombre . '.pdf"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=3600');
readfile($ruta);
