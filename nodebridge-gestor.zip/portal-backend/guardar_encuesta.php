<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
manejar_errores();
cors('POST, OPTIONS');

// Recibe la respuesta de un paciente a una encuesta.
// JSON: {"encuesta": 12, "respuestas": {"<id_pregunta>": "valor", ...}, "sitio_web": ""}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}
$datos = json_entrada();

// Campo trampa: los bots lo completan, las personas no lo ven.
if (!empty($datos['sitio_web'])) {
    json_out(['estado' => 'exito', 'mensaje' => 'Respuesta guardada correctamente']);
}

$idEncuesta = filter_var($datos['encuesta'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idEncuesta === false || $idEncuesta === null) {
    error_out('Encuesta inválida', 422);
}
$recibidas = $datos['respuestas'] ?? null;
if (!is_array($recibidas)) {
    error_out('No se recibieron respuestas', 422);
}

$encuesta = preparar('SELECT titulo, preguntas FROM encuestas WHERE id_externo = ?', 'i', [$idEncuesta])
    ->get_result()->fetch_assoc();
if (!$encuesta) {
    error_out('Esta encuesta ya no está disponible.', 404);
}
$preguntas = json_decode($encuesta['preguntas'], true);
if (!is_array($preguntas)) {
    throw new RuntimeException('Preguntas de la encuesta ' . $idEncuesta . ' dañadas');
}

// No se aceptan respuestas a preguntas que no son de esta encuesta.
$idsPreguntas = array_map(fn($p) => (string) $p['id'], $preguntas);
foreach (array_keys($recibidas) as $clave) {
    if (!in_array((string) $clave, $idsPreguntas, true)) {
        error_out('Hay una respuesta a una pregunta que no existe.', 422);
    }
}

$salida = [];
foreach ($preguntas as $p) {
    $valor = $recibidas[(string) $p['id']] ?? '';
    $valor = is_string($valor) || is_int($valor) ? trim((string) $valor) : '';

    if ($valor === '') {
        if (!empty($p['obligatoria'])) {
            error_out('Falta responder: ' . $p['texto'], 422);
        }
        continue;
    }

    if ($p['tipo'] === 'escala') {
        if (!in_array($valor, ['1', '2', '3', '4', '5'], true)) {
            error_out('La respuesta a «' . $p['texto'] . '» debe ser un número del 1 al 5.', 422);
        }
    } elseif ($p['tipo'] === 'opcion') {
        if (!in_array($valor, $p['opciones'] ?? [], true)) {
            error_out('La respuesta a «' . $p['texto'] . '» no es una de las opciones.', 422);
        }
    } else {   // texto libre
        $limpio = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $valor);
        if ($limpio === null) {
            error_out('El texto tiene caracteres inválidos.', 422);
        }
        $valor = trim($limpio);
        if (longitud_texto($valor) > 500) {
            error_out('El texto de «' . $p['texto'] . '» no puede superar los 500 caracteres.', 422);
        }
        if ($valor === '') {
            continue;
        }
    }

    $salida[] = ['pregunta_id' => (int) $p['id'], 'pregunta' => $p['texto'], 'tipo' => $p['tipo'], 'valor' => $valor];
}

if (!$salida) {
    error_out('Responda al menos una pregunta.', 422);
}

// Límite de envíos por IP (se guarda solo un hash, nunca la IP).
$ipHash = hash('sha256', ip_cliente() . '|' . env('IP_SALT', 'portal-hc'));
$max = (int) env('RATE_LIMIT_MAX', '5');
$minutos = (int) env('RATE_LIMIT_MINUTES', '10');
$recientes = (int) preparar(
    'SELECT COUNT(*) FROM respuestas WHERE ip_hash = ? AND fecha > (NOW() - INTERVAL ? MINUTE)',
    'si',
    [$ipHash, $minutos]
)->get_result()->fetch_row()[0];
if ($recientes >= $max) {
    error_out('Demasiados envíos. Intente nuevamente en unos minutos.', 429);
}

preparar(
    'INSERT INTO respuestas (uuid, encuesta_externo, respuestas_json, ip_hash) VALUES (?, ?, ?, ?)',
    'siss',
    [uuid_v4(), $idEncuesta, json_encode($salida, JSON_UNESCAPED_UNICODE), $ipHash]
);

json_out(['estado' => 'exito', 'mensaje' => 'Respuesta guardada correctamente'], 201);
