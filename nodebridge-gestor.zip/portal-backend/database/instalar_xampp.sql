-- Instalación completa para XAMPP: crea la base y carga estructura, categorías y documentos.
-- Importar desde phpMyAdmin (pestaña Importar) o con: mysql -u root < instalar_xampp.sql
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS portal_informativo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE portal_informativo;

SET NAMES utf8mb4;
-- Estructura del portal informativo (MariaDB / MySQL).
-- Se ejecuta sobre la base ya seleccionada (ver instalar_xampp.sql para XAMPP).

CREATE TABLE IF NOT EXISTS categorias (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documentos (
  id_documento INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NULL UNIQUE,                 -- id del documento en el gestor (NULL = propio del portal)
  titulo VARCHAR(150) NOT NULL,
  ruta_archivo VARCHAR(255) NOT NULL UNIQUE,  -- relativa a UPLOADS_DIR
  fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP,
  categoria_id INT NOT NULL,
  INDEX idx_documentos_categoria (categoria_id),
  FOREIGN KEY (categoria_id) REFERENCES categorias(id_categoria) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Encuestas que arma el administrador en el gestor y publica acá (los pacientes las responden).
-- Solo están acá las que están Activas en el gestor: si se desactiva o se borra, el gestor la retira.
CREATE TABLE IF NOT EXISTS encuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NOT NULL UNIQUE,             -- id de la encuesta en el gestor
  titulo VARCHAR(150) NOT NULL,
  descripcion VARCHAR(500) NULL,
  sector VARCHAR(100) NOT NULL,
  preguntas MEDIUMTEXT NOT NULL,              -- JSON: [{id, texto, tipo, opciones, obligatoria}]
  INDEX idx_encuestas_sector (sector)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS respuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,              -- identificador estable para sincronizar con el gestor
  encuesta_externo INT NULL,                  -- id de la encuesta en el gestor
  respuestas_json MEDIUMTEXT NULL,            -- JSON: [{pregunta_id, pregunta, tipo, valor}]
  clasificacion VARCHAR(20) NULL,             -- formato anterior (formulario fijo), solo respuestas viejas
  lugar VARCHAR(50) NULL,
  profesional VARCHAR(50) NULL,
  comentario VARCHAR(255) NULL,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  sincronizado TINYINT(1) NOT NULL DEFAULT 0, -- 1 = el gestor ya la guardó
  fecha_sincronizado DATETIME NULL,
  ip_hash CHAR(64) NULL,                      -- hash de la IP, solo para limitar envíos
  INDEX idx_respuestas_pendientes (sincronizado, id),
  INDEX idx_respuestas_ip (ip_hash, fecha)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET NAMES utf8mb4;
INSERT IGNORE INTO categorias (nombre) VALUES
  ('Unidad de Cuidados Paliativos'),
  ('Emergencia'),
  ('Neonatología'),
  ('Dpto. Clínico de medicina'),
  ('Cardiología'),
  ('Centro cardiovascular'),
  ('Clínica médica A'),
  ('Clínica médica B'),
  ('Clínica médica C'),
  ('Dermatología'),
  ('Endocrinología'),
  ('Gastroenterología'),
  ('Geriatría'),
  ('Hematología'),
  ('Infectología'),
  ('Medicina física, rehabilitación y medicina del deporte'),
  ('Nefrología'),
  ('Neurología'),
  ('Oncología'),
  ('Psiquiatría'),
  ('U.E. Autoinmunes sistémicas'),
  ('Unidad de tabaquismo'),
  ('Depto. Clínico de cirugía'),
  ('Anestesiología'),
  ('Cirugía plástica y quemados'),
  ('Cirugía vascular periférica'),
  ('Ginecotocológica B'),
  ('Neurocirugía'),
  ('Odontología'),
  ('Oftalmología'),
  ('Otorrinolaringología'),
  ('Quirúrgica A'),
  ('Quirúrgica B'),
  ('Quirúrgica F'),
  ('Urología'),
  ('Traumatología y ortopedia de adultos'),
  ('Radioterapia'),
  ('Medicina Nuclear'),
  ('Hemoterapia'),
  ('Imagenología');

SET NAMES utf8mb4;
INSERT IGNORE INTO documentos (titulo, ruta_archivo, categoria_id) VALUES
  ('Guía general de Unidad de Cuidados Paliativos 1', 'unidad-de-cuidados-paliativos/guia-general-de-unidad-de-cuidados-paliativos-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de Cuidados Paliativos')),
  ('Guía general de Unidad de Cuidados Paliativos 2', 'unidad-de-cuidados-paliativos/guia-general-de-unidad-de-cuidados-paliativos-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de Cuidados Paliativos')),
  ('Guía general de Unidad de Cuidados Paliativos 3', 'unidad-de-cuidados-paliativos/guia-general-de-unidad-de-cuidados-paliativos-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de Cuidados Paliativos')),
  ('Guía general de Emergencia 1', 'emergencia/guia-general-de-emergencia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Emergencia')),
  ('Guía general de Emergencia 2', 'emergencia/guia-general-de-emergencia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Emergencia')),
  ('Guía general de Emergencia 3', 'emergencia/guia-general-de-emergencia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Emergencia')),
  ('Guía general de Neonatología 1', 'neonatologia/guia-general-de-neonatologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neonatología')),
  ('Guía general de Neonatología 2', 'neonatologia/guia-general-de-neonatologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neonatología')),
  ('Guía general de Neonatología 3', 'neonatologia/guia-general-de-neonatologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neonatología')),
  ('Guía general de Dpto. Clínico de medicina 1', 'dpto-clinico-de-medicina/guia-general-de-dpto-clinico-de-medicina-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dpto. Clínico de medicina')),
  ('Guía general de Dpto. Clínico de medicina 2', 'dpto-clinico-de-medicina/guia-general-de-dpto-clinico-de-medicina-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dpto. Clínico de medicina')),
  ('Guía general de Dpto. Clínico de medicina 3', 'dpto-clinico-de-medicina/guia-general-de-dpto-clinico-de-medicina-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dpto. Clínico de medicina')),
  ('Indicaciones ecocardiograma con dobutamina', 'cardiologia/indicaciones-ecocardiograma-con-dobutamina.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cardiología')),
  ('Indicaciones para pacientes en tratamiento con warfarina', 'cardiologia/indicaciones-para-pacientes-en-tratamiento-con-warfarina.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cardiología')),
  ('Indicaciones ecocardiograma transesofágico', 'cardiologia/indicaciones-ecocardiograma-transesofagico.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cardiología')),
  ('Guía general de Centro cardiovascular 1', 'centro-cardiovascular/guia-general-de-centro-cardiovascular-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Centro cardiovascular')),
  ('Guía general de Centro cardiovascular 2', 'centro-cardiovascular/guia-general-de-centro-cardiovascular-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Centro cardiovascular')),
  ('Guía general de Centro cardiovascular 3', 'centro-cardiovascular/guia-general-de-centro-cardiovascular-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Centro cardiovascular')),
  ('Guía general de Clínica médica A 1', 'clinica-medica-a/guia-general-de-clinica-medica-a-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica A')),
  ('Guía general de Clínica médica A 2', 'clinica-medica-a/guia-general-de-clinica-medica-a-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica A')),
  ('Guía general de Clínica médica A 3', 'clinica-medica-a/guia-general-de-clinica-medica-a-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica A')),
  ('Guía general de Clínica médica B 1', 'clinica-medica-b/guia-general-de-clinica-medica-b-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica B')),
  ('Guía general de Clínica médica B 2', 'clinica-medica-b/guia-general-de-clinica-medica-b-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica B')),
  ('Guía general de Clínica médica B 3', 'clinica-medica-b/guia-general-de-clinica-medica-b-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica B')),
  ('Guía general de Clínica médica C 1', 'clinica-medica-c/guia-general-de-clinica-medica-c-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica C')),
  ('Guía general de Clínica médica C 2', 'clinica-medica-c/guia-general-de-clinica-medica-c-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica C')),
  ('Guía general de Clínica médica C 3', 'clinica-medica-c/guia-general-de-clinica-medica-c-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Clínica médica C')),
  ('Guía general de Dermatología 1', 'dermatologia/guia-general-de-dermatologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dermatología')),
  ('Guía general de Dermatología 2', 'dermatologia/guia-general-de-dermatologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dermatología')),
  ('Guía general de Dermatología 3', 'dermatologia/guia-general-de-dermatologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Dermatología')),
  ('Guía general de Endocrinología 1', 'endocrinologia/guia-general-de-endocrinologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Endocrinología')),
  ('Guía general de Endocrinología 2', 'endocrinologia/guia-general-de-endocrinologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Endocrinología')),
  ('Guía general de Endocrinología 3', 'endocrinologia/guia-general-de-endocrinologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Endocrinología')),
  ('Pauta para pacientes ostomizados (7 páginas)', 'gastroenterologia/pauta-para-pacientes-ostomizados-7-paginas.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Gastroenterología')),
  ('Guía general de Gastroenterología 2', 'gastroenterologia/guia-general-de-gastroenterologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Gastroenterología')),
  ('Guía general de Gastroenterología 3', 'gastroenterologia/guia-general-de-gastroenterologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Gastroenterología')),
  ('Guía general de Geriatría 1', 'geriatria/guia-general-de-geriatria-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Geriatría')),
  ('Guía general de Geriatría 2', 'geriatria/guia-general-de-geriatria-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Geriatría')),
  ('Guía general de Geriatría 3', 'geriatria/guia-general-de-geriatria-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Geriatría')),
  ('Guía general de Hematología 1', 'hematologia/guia-general-de-hematologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hematología')),
  ('Guía general de Hematología 2', 'hematologia/guia-general-de-hematologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hematología')),
  ('Guía general de Hematología 3', 'hematologia/guia-general-de-hematologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hematología')),
  ('Guía general de Infectología 1', 'infectologia/guia-general-de-infectologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Infectología')),
  ('Guía general de Infectología 2', 'infectologia/guia-general-de-infectologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Infectología')),
  ('Guía general de Infectología 3', 'infectologia/guia-general-de-infectologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Infectología')),
  ('Guía general de Medicina física, rehabilitación y medicina del deporte 1', 'medicina-fisica-rehabilitacion-y-medicina-del-deporte/guia-general-de-medicina-fisica-rehabilitacion-y-medicina-del-deporte-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina física, rehabilitación y medicina del deporte')),
  ('Guía general de Medicina física, rehabilitación y medicina del deporte 2', 'medicina-fisica-rehabilitacion-y-medicina-del-deporte/guia-general-de-medicina-fisica-rehabilitacion-y-medicina-del-deporte-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina física, rehabilitación y medicina del deporte')),
  ('Guía general de Medicina física, rehabilitación y medicina del deporte 3', 'medicina-fisica-rehabilitacion-y-medicina-del-deporte/guia-general-de-medicina-fisica-rehabilitacion-y-medicina-del-deporte-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina física, rehabilitación y medicina del deporte')),
  ('Guía general de Nefrología 1', 'nefrologia/guia-general-de-nefrologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Nefrología')),
  ('Guía general de Nefrología 2', 'nefrologia/guia-general-de-nefrologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Nefrología')),
  ('Guía general de Nefrología 3', 'nefrologia/guia-general-de-nefrologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Nefrología')),
  ('Guía general de Neurología 1', 'neurologia/guia-general-de-neurologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurología')),
  ('Guía general de Neurología 2', 'neurologia/guia-general-de-neurologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurología')),
  ('Guía general de Neurología 3', 'neurologia/guia-general-de-neurologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurología')),
  ('Guía general de Oncología 1', 'oncologia/guia-general-de-oncologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oncología')),
  ('Guía general de Oncología 2', 'oncologia/guia-general-de-oncologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oncología')),
  ('Guía general de Oncología 3', 'oncologia/guia-general-de-oncologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oncología')),
  ('Guía general de Psiquiatría 1', 'psiquiatria/guia-general-de-psiquiatria-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Psiquiatría')),
  ('Guía general de Psiquiatría 2', 'psiquiatria/guia-general-de-psiquiatria-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Psiquiatría')),
  ('Guía general de Psiquiatría 3', 'psiquiatria/guia-general-de-psiquiatria-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Psiquiatría')),
  ('Guía general de U.E. Autoinmunes sistémicas 1', 'u-e-autoinmunes-sistemicas/guia-general-de-u-e-autoinmunes-sistemicas-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'U.E. Autoinmunes sistémicas')),
  ('Guía general de U.E. Autoinmunes sistémicas 2', 'u-e-autoinmunes-sistemicas/guia-general-de-u-e-autoinmunes-sistemicas-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'U.E. Autoinmunes sistémicas')),
  ('Guía general de U.E. Autoinmunes sistémicas 3', 'u-e-autoinmunes-sistemicas/guia-general-de-u-e-autoinmunes-sistemicas-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'U.E. Autoinmunes sistémicas')),
  ('Guía general de Unidad de tabaquismo 1', 'unidad-de-tabaquismo/guia-general-de-unidad-de-tabaquismo-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de tabaquismo')),
  ('Guía general de Unidad de tabaquismo 2', 'unidad-de-tabaquismo/guia-general-de-unidad-de-tabaquismo-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de tabaquismo')),
  ('Guía general de Unidad de tabaquismo 3', 'unidad-de-tabaquismo/guia-general-de-unidad-de-tabaquismo-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Unidad de tabaquismo')),
  ('Guía general de Depto. Clínico de cirugía 1', 'depto-clinico-de-cirugia/guia-general-de-depto-clinico-de-cirugia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Depto. Clínico de cirugía')),
  ('Guía general de Depto. Clínico de cirugía 2', 'depto-clinico-de-cirugia/guia-general-de-depto-clinico-de-cirugia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Depto. Clínico de cirugía')),
  ('Guía general de Depto. Clínico de cirugía 3', 'depto-clinico-de-cirugia/guia-general-de-depto-clinico-de-cirugia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Depto. Clínico de cirugía')),
  ('Guía general de Anestesiología 1', 'anestesiologia/guia-general-de-anestesiologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Anestesiología')),
  ('Guía general de Anestesiología 2', 'anestesiologia/guia-general-de-anestesiologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Anestesiología')),
  ('Guía general de Anestesiología 3', 'anestesiologia/guia-general-de-anestesiologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Anestesiología')),
  ('Guía general de Cirugía plástica y quemados 1', 'cirugia-plastica-y-quemados/guia-general-de-cirugia-plastica-y-quemados-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía plástica y quemados')),
  ('Guía general de Cirugía plástica y quemados 2', 'cirugia-plastica-y-quemados/guia-general-de-cirugia-plastica-y-quemados-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía plástica y quemados')),
  ('Guía general de Cirugía plástica y quemados 3', 'cirugia-plastica-y-quemados/guia-general-de-cirugia-plastica-y-quemados-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía plástica y quemados')),
  ('Guía general de Cirugía vascular periférica 1', 'cirugia-vascular-periferica/guia-general-de-cirugia-vascular-periferica-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía vascular periférica')),
  ('Guía general de Cirugía vascular periférica 2', 'cirugia-vascular-periferica/guia-general-de-cirugia-vascular-periferica-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía vascular periférica')),
  ('Guía general de Cirugía vascular periférica 3', 'cirugia-vascular-periferica/guia-general-de-cirugia-vascular-periferica-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Cirugía vascular periférica')),
  ('Indicaciones de interrupción voluntaria del embarazo', 'ginecotocologica-b/indicaciones-de-interrupcion-voluntaria-del-embarazo.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Ginecotocológica B')),
  ('Guía general de Ginecotocológica B 2', 'ginecotocologica-b/guia-general-de-ginecotocologica-b-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Ginecotocológica B')),
  ('Guía general de Ginecotocológica B 3', 'ginecotocologica-b/guia-general-de-ginecotocologica-b-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Ginecotocológica B')),
  ('Guía general de Neurocirugía 1', 'neurocirugia/guia-general-de-neurocirugia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurocirugía')),
  ('Guía general de Neurocirugía 2', 'neurocirugia/guia-general-de-neurocirugia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurocirugía')),
  ('Guía general de Neurocirugía 3', 'neurocirugia/guia-general-de-neurocirugia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Neurocirugía')),
  ('Guía general de Odontología 1', 'odontologia/guia-general-de-odontologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Odontología')),
  ('Guía general de Odontología 2', 'odontologia/guia-general-de-odontologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Odontología')),
  ('Guía general de Odontología 3', 'odontologia/guia-general-de-odontologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Odontología')),
  ('Guía general de Oftalmología 1', 'oftalmologia/guia-general-de-oftalmologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oftalmología')),
  ('Guía general de Oftalmología 2', 'oftalmologia/guia-general-de-oftalmologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oftalmología')),
  ('Guía general de Oftalmología 3', 'oftalmologia/guia-general-de-oftalmologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Oftalmología')),
  ('Guía general de Otorrinolaringología 1', 'otorrinolaringologia/guia-general-de-otorrinolaringologia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Otorrinolaringología')),
  ('Guía general de Otorrinolaringología 2', 'otorrinolaringologia/guia-general-de-otorrinolaringologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Otorrinolaringología')),
  ('Guía general de Otorrinolaringología 3', 'otorrinolaringologia/guia-general-de-otorrinolaringologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Otorrinolaringología')),
  ('Guía general de Quirúrgica A 1', 'quirurgica-a/guia-general-de-quirurgica-a-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica A')),
  ('Guía general de Quirúrgica A 2', 'quirurgica-a/guia-general-de-quirurgica-a-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica A')),
  ('Guía general de Quirúrgica A 3', 'quirurgica-a/guia-general-de-quirurgica-a-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica A')),
  ('Guía general de Quirúrgica B 1', 'quirurgica-b/guia-general-de-quirurgica-b-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica B')),
  ('Guía general de Quirúrgica B 2', 'quirurgica-b/guia-general-de-quirurgica-b-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica B')),
  ('Guía general de Quirúrgica B 3', 'quirurgica-b/guia-general-de-quirurgica-b-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica B')),
  ('Guía general de Quirúrgica F 1', 'quirurgica-f/guia-general-de-quirurgica-f-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica F')),
  ('Guía general de Quirúrgica F 2', 'quirurgica-f/guia-general-de-quirurgica-f-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica F')),
  ('Guía general de Quirúrgica F 3', 'quirurgica-f/guia-general-de-quirurgica-f-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Quirúrgica F')),
  ('Prostatectomía radical (indicaciones e información para el paciente)', 'urologia/prostatectomia-radical-indicaciones-e-informacion-para-el-paciente.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Urología')),
  ('Guía general de Urología 2', 'urologia/guia-general-de-urologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Urología')),
  ('Guía general de Urología 3', 'urologia/guia-general-de-urologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Urología')),
  ('Guía general de Traumatología y ortopedia de adultos 1', 'traumatologia-y-ortopedia-de-adultos/guia-general-de-traumatologia-y-ortopedia-de-adultos-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Traumatología y ortopedia de adultos')),
  ('Guía general de Traumatología y ortopedia de adultos 2', 'traumatologia-y-ortopedia-de-adultos/guia-general-de-traumatologia-y-ortopedia-de-adultos-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Traumatología y ortopedia de adultos')),
  ('Guía general de Traumatología y ortopedia de adultos 3', 'traumatologia-y-ortopedia-de-adultos/guia-general-de-traumatologia-y-ortopedia-de-adultos-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Traumatología y ortopedia de adultos')),
  ('Guía general de Radioterapia 1', 'radioterapia/guia-general-de-radioterapia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Radioterapia')),
  ('Guía general de Radioterapia 2', 'radioterapia/guia-general-de-radioterapia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Radioterapia')),
  ('Guía general de Radioterapia 3', 'radioterapia/guia-general-de-radioterapia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Radioterapia')),
  ('Estudios diagnósticos con pertecneciato', 'medicina-nuclear/estudios-diagnosticos-con-pertecneciato.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina Nuclear')),
  ('Información sobre Centellograma de perfusión miocárdica', 'medicina-nuclear/informacion-sobre-centellograma-de-perfusion-miocardica.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina Nuclear')),
  ('Guía general de Medicina Nuclear 3', 'medicina-nuclear/guia-general-de-medicina-nuclear-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Medicina Nuclear')),
  ('Guía general de Hemoterapia 1', 'hemoterapia/guia-general-de-hemoterapia-1.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hemoterapia')),
  ('Guía general de Hemoterapia 2', 'hemoterapia/guia-general-de-hemoterapia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hemoterapia')),
  ('Guía general de Hemoterapia 3', 'hemoterapia/guia-general-de-hemoterapia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Hemoterapia')),
  ('Preparación para estudios imagenológicos', 'imagenologia/preparacion-para-estudios-imagenologicos.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Imagenología')),
  ('Guía general de Imagenología 2', 'imagenologia/guia-general-de-imagenologia-2.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Imagenología')),
  ('Guía general de Imagenología 3', 'imagenologia/guia-general-de-imagenologia-3.pdf', (SELECT id_categoria FROM categorias WHERE nombre = 'Imagenología'));
