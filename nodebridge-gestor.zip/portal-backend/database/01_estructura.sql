SET NAMES utf8mb4;
-- Estructura del portal informativo (MariaDB / MySQL).
-- Se ejecuta sobre la base ya seleccionada (ver instalar_xampp.sql para XAMPP).

CREATE TABLE IF NOT EXISTS categorias (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documentos (
  id_documento INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NULL UNIQUE,                 -- id del documento en el gestor (NULL = propio del portal)
  titulo VARCHAR(150) NOT NULL,
  ruta_archivo VARCHAR(255) NOT NULL UNIQUE,  -- relativa a UPLOADS_DIR
  fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP,
  categoria_id INT NOT NULL,
  INDEX idx_documentos_categoria (categoria_id),
  FOREIGN KEY (categoria_id) REFERENCES categorias(id_categoria) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Encuestas que arma el administrador en el gestor y publica acá (los pacientes las responden).
-- Solo están acá las que están Activas en el gestor: si se desactiva o se borra, el gestor la retira.
CREATE TABLE IF NOT EXISTS encuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_externo INT NOT NULL UNIQUE,             -- id de la encuesta en el gestor
  titulo VARCHAR(150) NOT NULL,
  descripcion VARCHAR(500) NULL,
  sector VARCHAR(100) NOT NULL,
  preguntas MEDIUMTEXT NOT NULL,              -- JSON: [{id, texto, tipo, opciones, obligatoria}]
  INDEX idx_encuestas_sector (sector)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS respuestas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,              -- identificador estable para sincronizar con el gestor
  encuesta_externo INT NULL,                  -- id de la encuesta en el gestor
  respuestas_json MEDIUMTEXT NULL,            -- JSON: [{pregunta_id, pregunta, tipo, valor}]
  clasificacion VARCHAR(20) NULL,             -- formato anterior (formulario fijo), solo respuestas viejas
  lugar VARCHAR(50) NULL,
  profesional VARCHAR(50) NULL,
  comentario VARCHAR(255) NULL,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  sincronizado TINYINT(1) NOT NULL DEFAULT 0, -- 1 = el gestor ya la guardó
  fecha_sincronizado DATETIME NULL,
  ip_hash CHAR(64) NULL,                      -- hash de la IP, solo para limitar envíos
  INDEX idx_respuestas_pendientes (sincronizado, id),
  INDEX idx_respuestas_ip (ip_hash, fecha)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
