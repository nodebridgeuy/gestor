<?php
declare(strict_types=1);

/**
 * Configuración compartida del backend del portal.
 * Los valores salen de variables de entorno (Render) o del archivo .env (XAMPP).
 * Una variable de entorno real siempre tiene prioridad sobre .env.
 */

function cargar_env(string $ruta): void
{
    if (!is_readable($ruta)) {
        return;
    }
    foreach (file($ruta, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linea) {
        $linea = trim($linea);
        if ($linea === '' || $linea[0] === '#' || strpos($linea, '=') === false) {
            continue;
        }
        [$clave, $valor] = explode('=', $linea, 2);
        $clave = trim($clave);
        $valor = trim(trim($valor), "\"'");
        if (getenv($clave) === false) {
            putenv("$clave=$valor");
        }
    }
}
cargar_env(__DIR__ . '/.env');

function env(string $clave, string $porDefecto = ''): string
{
    $v = getenv($clave);
    return ($v === false || $v === '') ? $porDefecto : $v;
}

/** Cantidad de caracteres (no bytes); funciona aunque no esté la extensión mbstring. */
function longitud_texto(string $texto): int
{
    if (function_exists('mb_strlen')) {
        return mb_strlen($texto, 'UTF-8');
    }
    return (int) preg_match_all('/./us', $texto);
}

function manejar_errores(): void
{
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
    set_error_handler(function (int $sev, string $msg, string $file, int $line) {
        if (!(error_reporting() & $sev)) {
            return false;
        }
        throw new ErrorException($msg, 0, $sev, $file, $line);
    });
    set_exception_handler(function (Throwable $e) {
        error_log('[portal] ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine());
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['estado' => 'error', 'mensaje' => 'Error interno del servidor'], JSON_UNESCAPED_UNICODE);
    });
}

function json_out(array $datos, int $codigo = 200)
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function error_out(string $mensaje, int $codigo)
{
    json_out(['estado' => 'error', 'mensaje' => $mensaje], $codigo);
}

function cors(string $metodos): void
{
    header('Access-Control-Allow-Origin: ' . env('ALLOWED_ORIGIN', '*'));
    header('Access-Control-Allow-Methods: ' . $metodos);
    header('Access-Control-Allow-Headers: Content-Type');
    header('Access-Control-Max-Age: 86400');
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function db(): mysqli
{
    static $conexion = null;
    if ($conexion !== null) {
        return $conexion;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $m = mysqli_init();
    $flags = 0;
    if (env('DB_SSL', '0') === '1') {
        $m->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, false);
        $m->ssl_set(null, null, null, null, null);
        $flags = MYSQLI_CLIENT_SSL;
    }
    $ok = @$m->real_connect(
        env('DB_HOST', '127.0.0.1'),
        env('DB_USER', 'root'),
        env('DB_PASS', ''),
        env('DB_NAME', 'portal_informativo'),
        (int) env('DB_PORT', '3306'),
        null,
        $flags
    );
    if (!$ok) {
        throw new RuntimeException('No se pudo conectar a la base: ' . mysqli_connect_error());
    }
    $m->set_charset('utf8mb4');
    return $conexion = $m;
}

/** Prepara, enlaza y ejecuta una consulta. Lanza excepción si falla. */
function preparar(string $sql, string $tipos = '', array $params = []): mysqli_stmt
{
    $stmt = db()->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Error preparando consulta: ' . db()->error);
    }
    if ($tipos !== '') {
        $stmt->bind_param($tipos, ...$params);
    }
    if (!$stmt->execute()) {
        throw new RuntimeException('Error ejecutando consulta: ' . $stmt->error);
    }
    return $stmt;
}

/** Lee el cuerpo JSON de la petición (con tope de tamaño). Responde el error y corta si no es válido. */
function json_entrada(int $maxBytes = 30720): array
{
    $crudo = file_get_contents('php://input', false, null, 0, $maxBytes + 1);
    if ($crudo === false || strlen($crudo) > $maxBytes) {
        error_out('Solicitud demasiado grande', 413);
    }
    $datos = json_decode($crudo, true);
    if (!is_array($datos)) {
        error_out('No se recibieron datos válidos', 400);
    }
    return $datos;
}

function requerir_api_key(): void
{
    $esperada = env('API_KEY');
    if ($esperada === '') {
        error_out('API no configurada en el servidor', 503);
    }
    $recibida = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if (!hash_equals($esperada, $recibida)) {
        error_out('No autorizado', 401);
    }
}

function ip_cliente(): string
{
    if (env('TRUST_PROXY', '0') === '1' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $partes = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($partes[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function uuid_v4(): string
{
    $b = random_bytes(16);
    $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
    $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
    $h = bin2hex($b);
    return sprintf('%s-%s-%s-%s-%s', substr($h, 0, 8), substr($h, 8, 4), substr($h, 12, 4), substr($h, 16, 4), substr($h, 20));
}

/** Carpeta donde viven los PDF (en Render: la ruta del disco persistente). */
function directorio_archivos(): string
{
    $dir = env('UPLOADS_DIR', __DIR__ . '/documentos');
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        throw new RuntimeException('No se pudo crear UPLOADS_DIR');
    }
    return rtrim((string) realpath($dir), '/\\');
}

/** Devuelve la ruta real del archivo solo si está dentro de la carpeta de archivos. */
function ruta_segura(string $relativa): ?string
{
    $base = directorio_archivos();
    $completa = realpath($base . DIRECTORY_SEPARATOR . $relativa);
    if ($completa === false || strpos($completa, $base . DIRECTORY_SEPARATOR) !== 0 || !is_file($completa)) {
        return null;
    }
    return $completa;
}
