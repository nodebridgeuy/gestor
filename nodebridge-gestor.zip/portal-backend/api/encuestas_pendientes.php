<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

// Devuelve las respuestas que el gestor todavía no confirmó. GET ?limite=100 (máx. 500)
// Formato nuevo: "respuestas" = lista pregunta por pregunta. Formato anterior (formulario fijo): clasificacion/lugar/...
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    error_out('Método no permitido', 405);
}
$limite = (int) ($_GET['limite'] ?? 100);
$limite = max(1, min($limite, 500));

$filas = preparar(
    'SELECT uuid, encuesta_externo, respuestas_json, clasificacion, lugar, profesional, comentario, fecha
       FROM respuestas
      WHERE sincronizado = 0
      ORDER BY id
      LIMIT ?',
    'i',
    [$limite]
)->get_result()->fetch_all(MYSQLI_ASSOC);

$encuestas = [];
foreach ($filas as $f) {
    $detalle = $f['respuestas_json'] !== null ? json_decode($f['respuestas_json'], true) : null;
    $encuestas[] = [
        'uuid' => $f['uuid'],
        'id_encuesta' => $f['encuesta_externo'] !== null ? (int) $f['encuesta_externo'] : null,
        'respuestas' => is_array($detalle) ? $detalle : null,
        'clasificacion' => $f['clasificacion'],
        'lugar' => $f['lugar'],
        'profesional' => $f['profesional'],
        'comentario' => $f['comentario'],
        'fecha' => $f['fecha'],
    ];
}

json_out(['estado' => 'exito', 'encuestas' => $encuestas]);
