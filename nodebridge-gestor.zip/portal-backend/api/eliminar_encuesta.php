<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

// Retira una encuesta del portal (el gestor la desactivó o la borró). POST: id_externo.
// Las respuestas que ya llegaron no se tocan: siguen esperando que el gestor las traiga.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}
$idExterno = filter_var($_POST['id_externo'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idExterno === false || $idExterno === null) {
    error_out('id_externo inválido', 422);
}
$stmt = preparar('DELETE FROM encuestas WHERE id_externo = ?', 'i', [$idExterno]);
if ($stmt->affected_rows === 0) {
    error_out('Encuesta no encontrada', 404);
}
json_out(['estado' => 'exito']);
