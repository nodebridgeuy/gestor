<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();
db()->query('SELECT 1');
json_out(['estado' => 'exito', 'mensaje' => 'ok']);
