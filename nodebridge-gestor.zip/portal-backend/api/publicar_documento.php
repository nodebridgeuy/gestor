<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

// Crea o actualiza un documento enviado por el gestor (clave: id_externo = id del gestor).
// POST multipart/form-data: id_externo, titulo, categoria, archivo (PDF; opcional al actualizar)

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}

$idExterno = filter_var($_POST['id_externo'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idExterno === false || $idExterno === null) {
    error_out('id_externo inválido', 422);
}
$titulo = trim((string) ($_POST['titulo'] ?? ''));
if ($titulo === '' || longitud_texto($titulo) > 150) {
    error_out('Título inválido (1 a 150 caracteres)', 422);
}
$categoria = trim((string) ($_POST['categoria'] ?? ''));
$filaCat = preparar('SELECT id_categoria FROM categorias WHERE nombre = ?', 's', [$categoria])
    ->get_result()->fetch_assoc();
if (!$filaCat) {
    error_out('La categoría no existe', 422);
}
$idCategoria = (int) $filaCat['id_categoria'];

$existente = preparar('SELECT id_documento, ruta_archivo FROM documentos WHERE id_externo = ?', 'i', [$idExterno])
    ->get_result()->fetch_assoc();

$nuevaRuta = null;
if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['archivo'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        error_out('Error al recibir el archivo (código ' . $f['error'] . ')', 400);
    }
    $maxBytes = (int) env('MAX_UPLOAD_MB', '10') * 1024 * 1024;
    if ($f['size'] > $maxBytes) {
        error_out('El archivo supera el tamaño máximo permitido', 413);
    }
    if (file_get_contents($f['tmp_name'], false, null, 0, 5) !== '%PDF-') {
        error_out('Solo se permiten archivos PDF', 422);
    }
    $carpeta = directorio_archivos() . DIRECTORY_SEPARATOR . 'externos';
    if (!is_dir($carpeta) && !@mkdir($carpeta, 0775, true)) {
        throw new RuntimeException('No se pudo crear la carpeta de documentos externos');
    }
    $nombre = $idExterno . '-' . bin2hex(random_bytes(6)) . '.pdf';
    if (!move_uploaded_file($f['tmp_name'], $carpeta . DIRECTORY_SEPARATOR . $nombre)) {
        throw new RuntimeException('No se pudo guardar el archivo');
    }
    $nuevaRuta = 'externos/' . $nombre;
}

if (!$existente) {
    if ($nuevaRuta === null) {
        error_out('Falta el archivo PDF', 422);
    }
    preparar(
        'INSERT INTO documentos (id_externo, titulo, ruta_archivo, categoria_id) VALUES (?, ?, ?, ?)',
        'issi',
        [$idExterno, $titulo, $nuevaRuta, $idCategoria]
    );
    json_out(['estado' => 'exito', 'accion' => 'creado'], 201);
}

if ($nuevaRuta !== null) {
    preparar(
        'UPDATE documentos SET titulo = ?, categoria_id = ?, ruta_archivo = ?, fecha_subida = NOW() WHERE id_externo = ?',
        'sisi',
        [$titulo, $idCategoria, $nuevaRuta, $idExterno]
    );
    $vieja = ruta_segura($existente['ruta_archivo']);
    if ($vieja !== null) {
        @unlink($vieja);
    }
} else {
    preparar(
        'UPDATE documentos SET titulo = ?, categoria_id = ? WHERE id_externo = ?',
        'sii',
        [$titulo, $idCategoria, $idExterno]
    );
}
json_out(['estado' => 'exito', 'accion' => 'actualizado']);
