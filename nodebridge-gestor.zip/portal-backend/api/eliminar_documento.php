<?php
declare(strict_types=1);
require __DIR__ . '/../config.php';
manejar_errores();
requerir_api_key();

// Elimina un documento publicado por el gestor. POST: id_externo
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_out('Método no permitido', 405);
}
$idExterno = filter_var($_POST['id_externo'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idExterno === false || $idExterno === null) {
    error_out('id_externo inválido', 422);
}

$fila = preparar('SELECT ruta_archivo FROM documentos WHERE id_externo = ?', 'i', [$idExterno])
    ->get_result()->fetch_assoc();
if (!$fila) {
    error_out('Documento no encontrado', 404);
}
preparar('DELETE FROM documentos WHERE id_externo = ?', 'i', [$idExterno]);
$ruta = ruta_segura($fila['ruta_archivo']);
if ($ruta !== null) {
    @unlink($ruta);
}
json_out(['estado' => 'exito']);
