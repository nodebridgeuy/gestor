<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
manejar_errores();
cors('GET, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    error_out('Método no permitido', 405);
}

$categoria = isset($_GET['categoria']) ? trim((string) $_GET['categoria']) : '';

if ($categoria !== '') {
    $stmt = preparar(
        'SELECT d.id_documento, d.titulo, d.fecha_subida
           FROM documentos d
           JOIN categorias c ON d.categoria_id = c.id_categoria
          WHERE c.nombre = ?
          ORDER BY d.titulo',
        's',
        [$categoria]
    );
} else {
    $stmt = preparar(
        'SELECT d.id_documento, d.titulo, d.fecha_subida, c.nombre AS categoria
           FROM documentos d
           JOIN categorias c ON d.categoria_id = c.id_categoria
          ORDER BY c.nombre, d.titulo'
    );
}

$documentos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
json_out(['estado' => 'exito', 'documentos' => $documentos]);
